@yield('css')

<link rel="stylesheet" href="{{ URL::asset('dist/fontawesome/css/all.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('dist/owl-carousel/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ URL::asset('dist/bootstrap/css/bootstrap.min.css') }}">

<link rel="stylesheet" href="{{ URL::asset('dist/css/style.css') }}">
<link rel="stylesheet" href="{{ URL::asset('dist/css/responsive.css') }}">
<link rel="stylesheet" href="{{ URL::asset('dist/animate/css/libs/animate.min.css') }}">
