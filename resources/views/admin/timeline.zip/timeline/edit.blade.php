@extends('admin.layouts.master')

@section('title')
    @lang('translation.Dashboards')
@endsection

@section('css')
    <link href="{{ URL::asset('build/libs/select2/css/select2.min.css') }}" rel="stylesheet" type="text/css" />
    <!-- Plugins css -->
    <!-- <link href="{{ URL::asset('build/libs/dropzone/dropzone.css') }}" rel="stylesheet" type="text/css" /> -->
@endsection
@section('content')
    @component('admin.components.breadcrumb')
        @slot('li_1')
            Dashboard
        @endslot
        @slot('title')
            Edit Timeline
        @endslot
    @endcomponent

    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title mb-4">Edit Timeline</h4>

                    <form method="post" action="{{ route('admin.timeline.update', $timeline->id) }}"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="title" name="title"
                                        placeholder="Enter Your Name"
                                        value="{{ old('title') ? old('title') : $timeline->title }}">
                                    @error('title')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="location" class="form-label">Location</label>
                                    <select class="form-select" name="location" id="location">
                                        <option>Select location</option>
                                        @forelse ($locations as $location)
                                            <option value="{{ $location->id }}"
                                                {{ $location->id == $timeline->location_id ? 'selected' : '' }}>
                                                {{ $location->name }}</option>
                                        @empty
                                            <option value="" disabled>No location available</option>
                                        @endforelse
                                    </select>
                                    @error('location')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="instructor" class="form-label">Instructor</label>
                                    <select class="form-select" name="instructor" id="instructor">
                                        <option disabled>Select instructor</option>
                                        @forelse ($instructors as $instructor)
                                            <option value="{{ $instructor->id }}"
                                                {{ $timeline->instructor_id == $instructor->id ? 'selected' : '' }}>
                                                {{ $instructor->name }}</option>
                                        @empty
                                            <option value="" disabled>No instructor available</option>
                                        @endforelse
                                    </select>
                                    @error('instructor')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            @php
                                // Assuming $selectedActivities is an array of selected activity IDs from the database
                                $selectedActivities = explode(',', $timeline->activity_ids); // If stored as a comma-separated string
                            @endphp
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="activities" class="form-label">Activities</label>
                                    <select class="select2 form-control select2-multiple" id="activities"
                                        name="activities[]" multiple="multiple" data-placeholder="Choose activities...">
                                        @forelse ($activities as $activity)
                                            <option value="{{ $activity->id }}"
                                                {{ in_array($activity->id, $selectedActivities) ? 'selected' : '' }}>
                                                {{ $activity->activity_name }}</option>
                                        @empty
                                            <option value="" disabled>No activities available</option>
                                        @endforelse
                                    </select>

                                    @error('activities')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror

                                </div>
                            </div>

                        </div>
                        <div class="row" style="align-items: baseline;">

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="description-editor" class="form-label">Description</label>
                                    {{-- <textarea required="" name="description" class="form-control" rows="3" id="description"
                                        placeholder="Enter Your Description">{{ old('description') ? old('description') : $timeline->description }}</textarea> --}}
                                    <textarea id="description-editor" name="description" class="form-control" rows="3" id="description"
                                        placeholder="Enter Your Description">{{ old('description') ? old('description') : $timeline->description }}</textarea>
                                    @error('description')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-date-input" class="col-md-2 col-form-label">Date</label>

                                    <input class="form-control" type="date" name="date"
                                        value="{{ old('date') ? old('date') : \Carbon\Carbon::parse($timeline->date)->format('Y-m-d') }}"
                                        id="example-date-input">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-time-input" class="col-md-2 col-form-label">Time</label>
                                    <input class="form-control" type="time" name="time"
                                        value="{{ old('time') ? old('time') : \Carbon\Carbon::parse($timeline->time)->format('H:i:s') }}"
                                        id="example-time-input">
                                </div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <div class="mt-3">
                                    <label for="formFile" class="form-label">Image</label>
                                    <input class="form-control" type="file" id="formFile" name="image">
                                    @error('image')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>



                        <!-- <textarea required="" class="form-control" rows="3" style="height: 17px;"></textarea> -->
                        <div>
                            <button type="submit" class="btn btn-primary w-md">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
    </div>
@endsection
@section('script')
    <!-- Plugins js -->
    <!-- <script src="{{ URL::asset('build/libs/dropzone/dropzone-min.js') }}"></script> -->

    <script src="{{ URL::asset('build/libs/select2/js/select2.min.js') }}"></script>
    <!-- Form file upload init js -->
    <!-- <script src="{{ URL::asset('build/js/pages/form-file-upload.init.js') }}"></script> -->
    <!-- form advanced init -->
    <script src="{{ URL::asset('build/js/pages/form-advanced.init.js') }}"></script>

    <!--tinymce js-->
    <script src="{{ URL::asset('build/libs/tinymce/tinymce.min.js') }}"></script>

    <!-- init js -->
    <script src="{{ URL::asset('build/js/pages/form-editor.init.js') }}"></script>

    <script>
        tinymce.init({
            selector: '#description-editor', // Match the ID of the textarea
            height: 300,
            menubar: false,
            plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks code fullscreen',
                'insertdatetime media table paste code help wordcount'
            ],
            toolbar: 'undo redo | formatselect | bold italic backcolor | \
                                                                            alignleft aligncenter alignright alignjustify | \
                                                                            bullist numlist outdent indent | removeformat | help'
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#location').change(function() {
                // Set up CSRF token for all AJAX requests
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                // console.log($(this).val());
                // return false;
                var locationId = $(this).val(); // Get selected location ID
                if (locationId) {
                    // Make AJAX call to fetch activities
                    $.ajax({
                        url: "{{ route('admin.timeline.getLocationActivities') }}", // Your route to fetch activities
                        type: "POST",
                        data: {
                            location_id: locationId
                        },
                        success: function(data) {
                            // Clear the activities select field before appending new options
                            $('#activities').empty();

                            if (data.activities.length > 0) {
                                $.each(data.activities, function(key, activity) {
                                    $('#activities').append('<option value="' + activity
                                        .id + '">' + activity.activity_name +
                                        '</option>');
                                });
                            } else {
                                $('#activities').append(
                                    '<option value="" disabled>No activities available</option>'
                                );
                            }

                            // Refresh the select2 field
                            $('#activities').trigger('change');
                        },
                        error: function(error) {
                            console.log("Error fetching activities:", error);
                        }
                    });
                } else {
                    // Clear the activities select if no location is selected
                    $('#activities').empty().append('<option value="" disabled>Select activities</option>');
                    $('#activities').trigger('change');
                }
            });
        });
    </script>
@endsection
